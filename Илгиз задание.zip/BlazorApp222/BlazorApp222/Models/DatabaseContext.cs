﻿using Microsoft.EntityFrameworkCore;

namespace BlazorApp222.Models
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options)
                : base(options)
        {
        }

        public DbSet<Person> Person { get; set; }
    }
}
